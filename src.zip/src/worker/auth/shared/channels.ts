export const AUTH_CHANNEL = 'angularfire2-auth';
export const INITIAL_AUTH_CHANNEL = 'angularfire2-auth-initial';
